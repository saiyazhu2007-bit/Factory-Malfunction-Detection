# Architecture Diagram

Copy the Mermaid diagram below into a Markdown viewer that supports Mermaid (or Mermaid Live Editor) to render it.

```mermaid
flowchart TD
    A[Machine data / benchmark dataset] --> B[Data ingestion]
    F[Factory I/O simulation] --> G[OPC UA communication]
    G --> B
    B --> C[Preprocessing]
    C --> D[Statistical features]
    C --> E[FFT features]
    D --> H[Feature matrix]
    E --> H
    H --> I[Autoencoder]
    I --> J[Reconstruction error / anomaly score]
    J --> K[Threshold decision]
    K --> L[Normal / flagged observation]
    L --> M[Streamlit dashboard]
```

**Note:** The benchmark-dataset branch and Factory I/O/OPC UA branch may be separate experiments. Verify actual connections in the code before presenting this as one deployed pipeline.
