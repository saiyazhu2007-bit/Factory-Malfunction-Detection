# Dataset Description

## Data sources
The project context references the NASA C-MAPSS turbofan engine degradation benchmark and machine simulation through Factory I/O. These sources serve different purposes and should not be treated as interchangeable.

### NASA C-MAPSS
C-MAPSS is a simulated turbofan-engine degradation dataset used for prognostics and predictive-maintenance research. The data commonly includes engine operating settings, sensor measurements, and cycle-based records. The exact subset (such as FD001–FD004), file names, columns, and train/test split should be recorded based on the data actually used in the experiment.

### Factory I/O
Factory I/O can be used to simulate industrial processes and provide machine variables for monitoring. Record the scene, signal names, sampling interval, and communication configuration if it is part of the experiment.

## Data preparation notes
- Do not commit large dataset files unless their license and repository limits permit.
- Keep raw data separate from processed features.
- Document the source, split, preprocessing, and feature columns.
- Avoid using test data to fit preprocessing or model parameters.

## Dataset card template
Fill in for your exact experiment:
- Dataset/source:
- Download/source link:
- Subset or scene:
- Number of rows:
- Number of features:
- Sampling rate/cycle meaning:
- Train/validation/test split:
- Preprocessing:
- Label availability:
- License/usage notes:
