# Methodology

## 1. Data acquisition
Data may come from a benchmark predictive-maintenance dataset, recorded sensor files, or Factory I/O simulation. The source and experiment split should be noted for every run.

## 2. Data inspection
- Check columns, data types, missing values, duplicates, and ranges.
- Review sensor values and machine operating conditions.
- Identify the target or cycle information if present in the benchmark data.

## 3. Preprocessing
- Handle missing or invalid observations using an appropriate documented strategy.
- Select relevant sensor columns.
- Scale features using parameters fitted on training data only.
- Keep train/test separation to avoid leakage.

## 4. Feature extraction
### Statistical features
Depending on the signal and windowing scheme, calculate measures such as mean, standard deviation, minimum, maximum, RMS, variance, and peak-to-peak range.

### Frequency-domain features
FFT can transform a time-domain signal into frequency-domain components. Relevant features may include spectral magnitude, dominant frequency, or selected band energy. Feature choices depend on the sampling rate and the actual implementation.

## 5. Autoencoder-based anomaly detection
An autoencoder is trained to reconstruct input features. During training, the model learns patterns represented in the training data. Reconstruction error is used as an anomaly score. Training on predominantly normal observations is a common approach for anomaly detection.

## 6. Threshold selection
The experiment's recorded threshold is 0.00315172048. Document how it was selected (e.g., validation distribution or tuning) and whether it applies to the exact preprocessing and model version. Do not transfer the threshold blindly to a different dataset or model.

## 7. Anomaly labeling
Compare each sample's anomaly score with the threshold. Scores above the threshold are flagged for review. The threshold inequality and score definition must match the code.

## 8. Visualization
Use the dashboard to inspect summary counts, signal trends, anomaly scores, and flagged records as supported by the actual application.

## 9. Evaluation
Where labels are available, assess anomaly detection with appropriate classification metrics and plots. Without reliable labels, counts and score distributions are descriptive—not accuracy measurements.
