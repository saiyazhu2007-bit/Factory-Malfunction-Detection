# Installation and Usage Guide

## Prerequisites
- Python version compatible with the project dependencies
- Git (optional, for cloning)
- Project source code
- Dataset files, if required
- Factory I/O and OPC UA configuration, if using the simulation integration

## Clone the repository
Replace the placeholder below with your GitHub repository URL after publishing:
```bash
git clone <YOUR_REPOSITORY_URL>
cd Factory-Malfunction-Detection
```

## Create a virtual environment
### Windows
```bash
python -m venv .venv
.venv\\Scripts\\activate
```

### Linux/macOS
```bash
python3 -m venv .venv
source .venv/bin/activate
```

## Install dependencies
```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## Run the dashboard
If the Streamlit entry point is `dashboard/app.py`:
```bash
streamlit run dashboard/app.py
```
Use the correct path if your app file is elsewhere.

## Data and configuration
Place datasets in the location expected by the code. Do not expose private credentials, OPC UA passwords, or sensitive machine configurations in the repository.

## Troubleshooting
- If imports fail, verify the virtual environment and dependency versions.
- If data files are not found, check the configured relative paths.
- If OPC UA connection fails, confirm server address, endpoint, security settings, and server availability.
- If the dashboard does not start, verify the Streamlit command and app path.
