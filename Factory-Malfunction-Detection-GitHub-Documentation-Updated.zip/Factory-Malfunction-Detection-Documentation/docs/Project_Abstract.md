# Project Abstract

Industrial equipment can develop abnormal operating behavior before a visible breakdown. Detecting deviations in machine data can help maintenance teams investigate potential issues earlier. This project explores an AI-based factory malfunction detection and predictive-maintenance workflow using machine data, signal-processing techniques, and an autoencoder-based anomaly-detection approach.

The workflow includes data preparation, statistical feature extraction, frequency-domain analysis using Fast Fourier Transform (FFT), model-based anomaly scoring, and visualization through a Streamlit dashboard. Where configured, Factory I/O can provide simulated machine behavior and OPC UA can be used to communicate machine signals to a Python application. The project also references the NASA C-MAPSS turbofan dataset as a predictive-maintenance benchmark, subject to the exact dataset split and experiment used.

The autoencoder learns patterns from data and assigns anomaly scores based on reconstruction error. Samples with scores above a chosen threshold are flagged for further inspection. In the recorded experiment, the threshold was 0.00315172048, with 655 samples flagged and 12,441 samples classified as normal.

The project demonstrates a practical learning pipeline for machine-data monitoring and anomaly detection. Its outputs are intended to assist investigation and maintenance planning; anomaly flags are not equivalent to verified equipment failures.
