# System Architecture

## Components
- **Machine data source:** benchmark dataset, sensor file, or simulated machine signals.
- **Factory I/O:** optional machine simulation environment.
- **OPC UA:** optional communication layer for publishing/reading machine variables.
- **Python ingestion:** reads data or communicates with the data source.
- **Preprocessing:** validates, cleans, scales, and prepares observations.
- **Feature extraction:** statistical features and FFT-derived features, depending on input signals.
- **Autoencoder:** learns data representations and reconstructs input samples.
- **Anomaly scoring:** calculates reconstruction error and compares it with a threshold.
- **Streamlit dashboard:** displays signals, scores, anomaly flags, and summary information.

## Data flow
1. Machine or dataset generates/contains signals.
2. Python obtains the observations.
3. Data is cleaned and transformed.
4. Features are extracted.
5. Model reconstruction error is calculated.
6. Threshold logic labels samples as normal or flagged.
7. Dashboard presents results.

## Integration status
Factory I/O and OPC UA are described as project components, but their actual integration should be verified against the uploaded code and configuration. A benchmark-dataset experiment may run separately from the live simulation pipeline.
