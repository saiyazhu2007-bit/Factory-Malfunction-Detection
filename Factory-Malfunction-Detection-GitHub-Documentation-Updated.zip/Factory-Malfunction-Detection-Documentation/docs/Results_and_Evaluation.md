# Results and Evaluation

## 1. Experimental Summary

The recorded experiment applied an autoencoder-based anomaly-detection workflow to prepared machine-condition data. The model's reconstruction error was compared with a selected threshold to separate observations classified as normal from observations flagged for further investigation.

The recorded threshold for this experiment was:

**Anomaly threshold: `0.00315172048`**

The recorded output contained **13,096 observations** in total.

## 2. Detection Results

| Output category | Number of samples | Percentage |
|---|---:|---:|
| Classified as normal | 12,441 | 95.00% |
| Flagged as anomalous | 655 | 5.00% |
| **Total** | **13,096** | **100.00%** |

The percentages are calculated from the recorded sample counts and rounded to two decimal places.

## 3. Interpretation

The detector classified 12,441 observations (95.00%) as normal and flagged 655 observations (5.00%) as anomalous under the selected threshold.

In an autoencoder-based approach, the model attempts to reconstruct its input. A larger reconstruction error indicates that an observation differs from the patterns represented by the model during training. The threshold is used to decide which reconstruction errors should be flagged.

An anomaly flag indicates an unusual observation relative to the learned data patterns. It does **not** by itself confirm that a machine has malfunctioned, identify a specific fault, or prove that a failure will occur. Flagged observations should be reviewed alongside the corresponding sensor readings, operating conditions, and machine state.

## 4. Threshold

The recorded threshold is `0.00315172048`.

The threshold is meaningful only for the model and preprocessing pipeline for which it was selected. Changes to feature selection, scaling, model weights, input data, or reconstruction-error calculation can change the score distribution. Therefore, the threshold should be revalidated whenever those elements change.

For reproducibility, the experiment record should also specify:
- The reconstruction-error formula used.
- Whether the comparison is `>` or `>=`.
- The validation data and method used to select the threshold.
- The model checkpoint and preprocessing/scaler version.

These implementation details should be copied from the actual project code or experiment logs.

## 5. Evaluation and Metrics

The available recorded results provide the number of normal and flagged observations. They do not provide ground-truth fault labels or a comparison between predictions and verified outcomes.

For that reason, the following classification metrics cannot be calculated reliably from the recorded counts alone:
- Accuracy
- Precision
- Recall
- F1-score
- False-positive rate
- ROC-AUC or PR-AUC

These metrics require suitable ground-truth labels and a defined evaluation split. They should only be added after evaluating predictions against those labels.

## 6. Recommended Result Visualizations

For a complete experimental report, include plots generated from the actual experiment outputs:
1. Bar or pie chart showing normal and flagged sample counts.
2. Reconstruction-error distribution with the threshold marked.
3. Time-series plot of sensor values with flagged observations highlighted, if timestamps or sequence order are available.
4. Example records showing the features and scores of selected flagged observations.

Do not create illustrative plots and present them as measured model outputs. Generate them from the saved predictions and experiment data.

## 7. Limitations

- Anomaly detection identifies deviations from learned patterns; it is not automatically a fault-diagnosis model.
- Unusual but harmless operating conditions may be flagged.
- Some faults may not be detected if their patterns resemble normal data.
- Threshold selection affects the number of flagged observations.
- Results depend on data quality, feature engineering, preprocessing, and the model version.
- Benchmark or simulated results do not establish performance on a real factory production line.

## 8. Conclusion

In the recorded experiment, the autoencoder-based detector processed 13,096 observations. Using the recorded threshold of `0.00315172048`, it classified 12,441 observations (95.00%) as normal and flagged 655 observations (5.00%) for further investigation.

These results demonstrate the output of the implemented threshold-based anomaly-detection workflow. Further validation using labeled fault data, threshold analysis, and expert review is required before making claims about predictive accuracy or real-world malfunction prevention.
