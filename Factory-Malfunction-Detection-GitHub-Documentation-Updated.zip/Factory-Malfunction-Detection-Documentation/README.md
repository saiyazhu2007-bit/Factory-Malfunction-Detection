# AI-Based Factory Malfunction Detection & Predictive Maintenance

An AI-assisted predictive-maintenance project that explores machine-condition monitoring, signal processing, and anomaly detection to identify potentially abnormal operating patterns.

## Overview
The project combines simulated industrial-machine data and/or benchmark predictive-maintenance data with Python-based preprocessing, feature extraction, an autoencoder anomaly-detection model, and a Streamlit dashboard for visual exploration.

> **Scope note:** The repository documentation describes the project workflow. Confirm that each component is present in your uploaded code before claiming it is fully integrated or deployed.

## Objectives
- Explore machine-condition data for abnormal operating patterns.
- Preprocess sensor data and derive useful features.
- Apply signal-processing techniques such as FFT where applicable.
- Train/use an autoencoder to learn normal patterns and flag deviations.
- Present monitoring information in a dashboard.
- Support predictive-maintenance investigation and reduce reliance on reactive inspection.

## Workflow
1. Obtain machine or benchmark data.
2. Inspect and preprocess data.
3. Extract statistical and frequency-domain features.
4. Train or load the anomaly-detection model.
5. Calculate reconstruction error.
6. Compare error with a selected threshold.
7. Visualize data and anomaly flags in the dashboard.

## Technologies
- Python
- NumPy / Pandas
- FFT-based signal analysis
- Autoencoder neural network
- Streamlit
- Factory I/O (simulation, where configured)
- OPC UA (industrial data communication, where configured)
- NASA C-MAPSS benchmark dataset (if used in the current experiment)

## Anomaly Detection
The recorded experiment threshold is `0.00315172048`. Confirm the error metric, preprocessing, and model version associated with this threshold before reuse. Samples whose anomaly score exceeds the selected threshold may be flagged for investigation.

## Recorded experiment counts
- Normal samples: **12,441**
- Flagged anomalies: **655**

These are recorded counts from the project context, not a statement of accuracy, precision, recall, or real-world failure prediction performance. Recalculate them if the dataset or pipeline changes.

## Repository structure (suggested)
```text
Factory-Malfunction-Detection/
├── README.md
├── docs/
│   ├── Project_Abstract.md
│   ├── Problem_Statement.md
│   ├── System_Architecture.md
│   ├── Methodology.md
│   ├── Dataset_Description.md
│   ├── Model_Documentation.md
│   ├── Results_and_Evaluation.md
│   ├── Installation_Guide.md
│   ├── Future_Enhancements.md
│   └── Architecture_Diagram.md
├── dashboard/
│   └── app.py
├── src/
│   └── (preprocessing and model files)
├── data/
│   └── (keep datasets out of Git unless licensing permits)
├── requirements.txt
└── .gitignore
```

## Run the dashboard
After adding the actual dashboard file and installing dependencies:
```bash
python -m pip install -r requirements.txt
streamlit run dashboard/app.py
```
Adjust the entry-point path to match your project.

## Results
See `docs/Results_and_Evaluation.md` for the recorded counts and limitations.

## Responsible interpretation
Anomaly flags indicate unusual patterns, not confirmed mechanical failures. Inspect the flagged sample, sensor context, and machine state before making maintenance decisions.

## Future work
See `docs/Future_Enhancements.md`.

## Author
Add your name, contact, and project links here if you wish.
